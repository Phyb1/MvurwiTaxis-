# WhatsApp Status Variants

Short posts intended to be mixed across the fortnight.

## 1 — First 20

🚖 FIRST 20 MVURWITAXIS DRIVERS

5 already registered.

Next target: 20.

Want your taxi listed?

DM **JOIN**.

## 2 — Your taxi online

Your taxi is already working in Mvurwi.

Why not put it online too? 🚖

MvurwiTaxis

DM **JOIN**.

## 3 — One profile

Instead of reposting your taxi advert everywhere…

Put your taxi on MvurwiTaxis.

One profile.
One link.
WhatsApp contact.

DM **JOIN**.

## 4 — Social proof

🚕 5 drivers have already joined MvurwiTaxis.

Who will be next?

DM **JOIN**.

## 5 — Driver referral

Know a Mvurwi taxi driver?

Tag them / send them this message:

**MvurwiTaxis is onboarding its first 20 drivers.** 🚖

## 6 — Local

**Mvurwi taxis. Mvurwi passengers. One local platform.** 🇿🇼🚖

MvurwiTaxis

DM **JOIN**.

## 7 — Product

This is what passengers can see 👇

[attach screen recording of real listings]

Want your taxi here?

DM **JOIN**.

## 8 — Simple

🚖 Mvurwi taxi?

Get listed.

Free driver listing.

DM **JOIN**.

## 9 — Progress

**[X] / 20** 🚕

We're building the first MvurwiTaxis driver network.

Join us.

## 10 — Question

If someone searches for a taxi in Mvurwi today…

**Can they find yours online?** 👀

MvurwiTaxis

DM **JOIN**.

## 11 — Build together

We're not trying to build everything overnight.

We're building MvurwiTaxis one driver at a time. 🚖

Currently: **[X] drivers**

Target: **20**

## 12 — CTA only

🚕 **JOIN MVURWITAXIS**

First 20-driver network.

DM **JOIN**.

https://www.mvurwitaxis.co.zw/signup/
