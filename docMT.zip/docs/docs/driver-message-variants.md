# Driver Recruitment Message Variants

Use these in rotation. Do not send all of them to the same person.

## Variant A — First 20

Hi 👋 I'm Phyb from MvurwiTaxis.

We're building our first 20-driver network in Mvurwi. We already have 5 drivers registered and are looking for the next drivers to join.

Want your taxi listed? I can send you the signup link.

## Variant B — One-link

Hi 👋 Do you advertise your taxi in WhatsApp groups?

MvurwiTaxis gives you one online profile where passengers can find your taxi and contact you directly.

We're currently onboarding drivers. Listing is free.

Interested?

## Variant C — Short

🚖 Mvurwi taxi drivers:

We're registering the first 20 taxis on MvurwiTaxis.

Free listing + passenger WhatsApp contact.

Want to join? Reply **JOIN**.

## Variant D — Local

Hi 👋 We're building a taxi platform specifically for Mvurwi.

The idea is simple: passengers find local taxis online and contact drivers directly.

We're starting with a small group of drivers and are currently at 5.

Would you like to be included?

## Variant E — Referral

Hi 👋 Quick one — do you know any other Mvurwi taxi drivers?

We're building the first 20-driver MvurwiTaxis network and looking for drivers to join.

If you know someone interested, please send them our signup link:
https://www.mvurwitaxis.co.zw/signup/

## Variant F — Follow-up

Hi 👋 just following up on MvurwiTaxis.

We're still onboarding the first group of Mvurwi drivers.

If you'd like your taxi listed, here's the link:
https://www.mvurwitaxis.co.zw/signup/

No pressure — just keeping the invitation open.

## Variant G — After signup interest

Great 👍

Here's the signup link:
https://www.mvurwitaxis.co.zw/signup/

Once you've registered, send me a message so I can check your listing and help you complete anything that's missing.

## Variant H — Group reply moved to DM

Hi 👋 I saw your taxi post in the group and didn't want to advertise in the group itself.

I'm building MvurwiTaxis, a local directory where passengers can find taxi drivers and contact them directly.

We're currently onboarding the first 20 drivers.

Can I send you the details?
