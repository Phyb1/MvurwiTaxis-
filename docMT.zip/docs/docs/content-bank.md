# MvurwiTaxis — Quick Content Bank

## Hooks

- "We're building the first 20."
- "5 drivers are already in."
- "Is your taxi listed?"
- "Mvurwi taxi drivers — this one's for you."
- "What does a passenger see when they search for a taxi in Mvurwi?"
- "Your taxi is already on the road. Put it online too."
- "Know a Mvurwi taxi driver?"
- "We're building MvurwiTaxis one driver at a time."

## CTAs

- DM **JOIN**
- Register your taxi
- Get listed
- Join the first 20
- Send this to a taxi driver
- Ask us about joining

## Proof assets to collect

- Screenshot of real driver listing
- Driver profile screenshot
- Driver vehicle photo with permission
- Short driver testimonial
- Signup completion screenshot (hide personal data)
- Directory count screenshot
- Screen recording from listing to WhatsApp

## Claims to avoid unless verified

- "Guaranteed customers"
- "Earn more"
- "More passengers" as a certainty
- "Thousands of passengers"
- "The biggest taxi platform"
- "Guaranteed bookings"
- Fake testimonials or fabricated passenger activity
