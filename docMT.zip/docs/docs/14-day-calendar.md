# MvurwiTaxis — 14-Day Content Calendar

## Day 1 — First 20

**Status/Post**

🚖 **MVURWITAXIS — FIRST 20 DRIVERS**

We're building the first group of taxis on MvurwiTaxis.

Already registered: **5 drivers** ✅

Next target: **15–20 drivers** 🚕

Want your taxi listed?

DM **JOIN** or register:
https://www.mvurwitaxis.co.zw/signup/

**CTA:** JOIN

---

## Day 2 — One link

**Status/Post**

Taxi available 24/7?

Instead of typing the same advert into different groups every day, put your taxi online once.

Passengers can find your profile and contact you on WhatsApp.

🚖 **MvurwiTaxis**

Free driver listing.

DM **JOIN**.

---

## Day 3 — Real drivers

**Status/Post**

🚕 **5 Mvurwi taxi drivers are already listed.**

We're now looking for the next drivers to join them.

Your name.
Your vehicle.
Your contact.

All in one place.

**Would your taxi be the next one?**

DM **JOIN** 👇

---

## Day 4 — Direct recruitment

No public post required. Spend the day contacting drivers who already advertise taxis in WhatsApp groups.

**DM:**

Hi 👋 Saw your taxi advert in the group.

I'm building MvurwiTaxis, a local taxi directory where passengers can find drivers and contact them directly on WhatsApp.

We're currently building our first 20 drivers and listing is free.

Interested? I can send you the signup link.

---

## Day 5 — Product proof

**Status/Post with a screen recording**

This is what a passenger sees 👇

1️⃣ Opens MvurwiTaxis
2️⃣ Sees available taxi profiles
3️⃣ Chooses a driver
4️⃣ Taps WhatsApp

We're building the network one Mvurwi taxi at a time.

🚖 Want your taxi listed?

DM **JOIN**.

---

## Day 6 — Referral day

**Status/Post**

🚕 **Mvurwi taxi drivers — help us build the network.**

Know another driver who should be listed on MvurwiTaxis?

Send them this message:

**"MvurwiTaxis is registering the first 20 drivers. Join free: https://www.mvurwitaxis.co.zw/signup/"**

Let's build it together.

---

## Day 7 — Local identity

**Status/Post**

**Built for Mvurwi taxis. 🇿🇼🚖**

Not Harare.
Not Bulawayo.

Mvurwi.

MvurwiTaxis is creating a simple online place where passengers can find local taxis and contact drivers directly.

We're looking for the next drivers to join.

DM **JOIN**.

---

## Day 8 — Driver benefit angle

**Status/Post**

Your taxi is already your business.

MvurwiTaxis gives you another place where people can find it online.

🚖 Driver profile
📱 WhatsApp contact
📍 Mvurwi-focused directory
📝 Simple signup

Join the first 20 drivers.

DM **JOIN**.

---

## Day 9 — FAQ

**Status/Post**

❓ **What is MvurwiTaxis?**

It's a local platform connecting passengers with taxis in Mvurwi.

❓ **Who can join?**

Mvurwi taxi drivers who meet the platform's requirements.

❓ **How do I register?**

Sign up online or message us.

🚕 First 20-driver campaign is underway.

https://www.mvurwitaxis.co.zw/signup/

---

## Day 10 — Driver testimonial

Use a real driver photo/video if permission is given.

**Caption:**

🚖 **MEET ONE OF OUR MVURWITAXIS DRIVERS**

[Driver name] is now listed on MvurwiTaxis.

We're currently building our first 20-driver network.

Want your taxi listed too?

DM **JOIN**.

**Video questions:**
- How did you hear about MvurwiTaxis?
- What made you decide to register?
- What would you tell another Mvurwi driver?

Do not script the driver's answer.

---

## Day 11 — Progress update

Update the number to the real figure.

🚖 **MVURWITAXIS DRIVER COUNT**

**[X] / 20**

We're getting closer to our first 20 drivers.

If you're a Mvurwi taxi driver and want to be listed, this is your chance to join the early network.

DM **JOIN**.

---

## Day 12 — Short/simple

**Status**

🚕 **Mvurwi taxi?**

Get listed on MvurwiTaxis.

Your profile.
Your vehicle.
Your WhatsApp.

**Join the first 20.**

DM **JOIN**.

---

## Day 13 — Founder/build-in-public angle

**Status/Post**

We're building MvurwiTaxis step by step.

Started with an idea.

Now we have **[X] drivers registered.** 🚖

Next milestone: **20 drivers.**

If you're a Mvurwi taxi driver, we'd like to have you on the platform.

DM **JOIN**.

---

## Day 14 — Countdown / milestone

**Status/Post**

🚖 **THE FIRST 20**

MvurwiTaxis is building its first 20-driver network.

Current count: **[X] / 20**

If you've been thinking about joining, now is a good time to get listed.

👉 https://www.mvurwitaxis.co.zw/signup/

Or DM **JOIN**.

---

# Daily execution

Each day:

- Post the day's main status
- Contact 3–5 new drivers personally
- Follow up with 2–3 warm leads
- Ask at least one existing driver for a referral on Days 6 and 10
- Record new leads and their source
- Update the driver count when a signup is confirmed

# What success looks like

Do not judge the fortnight by likes alone. Track:

**People contacted → interested → signup started → registered → verified → recently active**
