# 14-Day Short Video Ideas

Keep videos vertical and short. Use real screen recordings and real drivers where possible.

## Video 1 — 5 to 20

**Hook:**
"We're at 5. We're building to 20."

Show driver profiles.

**Voiceover:**
"MvurwiTaxis is building its first local taxi network. Five drivers are already registered. We're looking for the next 15."

End screen:
"Are you a Mvurwi taxi driver? DM JOIN."

## Video 2 — What happens when a passenger taps?

Show:
Homepage → driver profile → WhatsApp button.

Voiceover:
"A passenger finds a taxi, opens the profile and taps WhatsApp. That's the connection we're building."

End:
"Get your taxi listed. DM JOIN."

## Video 3 — Stop reposting

Open with a mock WhatsApp taxi advert.

Text:
"Posting this every day?"

Cut to MvurwiTaxis profile.

Text:
"Put it online once."

End:
"MvurwiTaxis — DM JOIN."

## Video 4 — Meet a driver

Film a real driver.

Ask:
"What's your name?"
"What taxi do you drive?"
"Why did you join MvurwiTaxis?"

Keep the driver's natural answer.

## Video 5 — Build in public

Show the admin/dashboard or directory count.

Text:
"5 drivers → 20 drivers"

Voiceover:
"We're building MvurwiTaxis one driver at a time."

## Video 6 — The local angle

Show Mvurwi streets / taxi rank / vehicle, where filming is permitted.

Text:
"Built for Mvurwi."

Then show website.

"MvurwiTaxis"

"Join the first 20 drivers."

## Video 7 — Referral

Text on screen:
"Know a Mvurwi taxi driver?"

"Send them this video."

Then:
"First 20 drivers are being onboarded."

## Video 8 — Progress update

Use the real number.

"MvurwiTaxis"
"[X] / 20 drivers"

"We're getting there."

End:
"DM JOIN"

# Filming rules

- 15–35 seconds is enough.
- Put the key message in the first 2–3 seconds.
- Use subtitles.
- Show the actual website whenever possible.
- Don't use fake passenger orders or fake testimonials.
- Get permission before filming a driver's face, vehicle, phone number or profile.
