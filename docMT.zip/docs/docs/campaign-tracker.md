# MvurwiTaxis — Fortnight Tracker

| Day | New drivers | Total | Verified | New leads | Follow-ups | Referrals | Notes |
|---|---:|---:|---:|---:|---:|---:|---|
| 1 | | 5 | | | | | |
| 2 | | | | | | | |
| 3 | | | | | | | |
| 4 | | | | | | | |
| 5 | | | | | | | |
| 6 | | | | | | | |
| 7 | | | | | | | |
| 8 | | | | | | | |
| 9 | | | | | | | |
| 10 | | | | | | | |
| 11 | | | | | | | |
| 12 | | | | | | | |
| 13 | | | | | | | |
| 14 | | | | | | | |

## Lead log

| Driver | Contact | Source | First contact | Interested? | Signup? | Verified? | Follow-up | Notes |
|---|---|---|---|---|---|---|---|---|
| | | WhatsApp / referral / rank / other | | | | | | |

## End-of-fortnight review

- Total drivers registered:
- Total verified:
- Drivers active/recently online:
- Total prospects contacted:
- Total interested:
- Total signups:
- Best-performing message:
- Best-performing channel:
- Number of referrals:
- Number of driver testimonials collected:
- Best video/status:
- What to change next fortnight:
